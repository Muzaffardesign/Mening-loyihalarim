﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.raqam7 = New System.Windows.Forms.Button()
        Me.raqam8 = New System.Windows.Forms.Button()
        Me.raqam9 = New System.Windows.Forms.Button()
        Me.btnkopaytirish = New System.Windows.Forms.Button()
        Me.btnbolish = New System.Windows.Forms.Button()
        Me.btnqoshish = New System.Windows.Forms.Button()
        Me.btnayirish = New System.Windows.Forms.Button()
        Me.raqam4 = New System.Windows.Forms.Button()
        Me.raqam1 = New System.Windows.Forms.Button()
        Me.raqam2 = New System.Windows.Forms.Button()
        Me.raqam3 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.tozalash = New System.Windows.Forms.Button()
        Me.raqam5 = New System.Windows.Forms.Button()
        Me.raqam6 = New System.Windows.Forms.Button()
        Me.lbldisplay = New System.Windows.Forms.Label()
        Me.btnteng = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(392, 197)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(39, 30)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "x*2"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(392, 299)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(39, 30)
        Me.Button9.TabIndex = 10
        Me.Button9.Text = "x*y"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(107, 96)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(39, 30)
        Me.Button10.TabIndex = 11
        Me.Button10.Text = "M+"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'raqam7
        '
        Me.raqam7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam7.Location = New System.Drawing.Point(107, 145)
        Me.raqam7.Name = "raqam7"
        Me.raqam7.Size = New System.Drawing.Size(39, 30)
        Me.raqam7.TabIndex = 12
        Me.raqam7.Text = "7"
        Me.raqam7.UseVisualStyleBackColor = True
        '
        'raqam8
        '
        Me.raqam8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam8.Location = New System.Drawing.Point(163, 145)
        Me.raqam8.Name = "raqam8"
        Me.raqam8.Size = New System.Drawing.Size(39, 30)
        Me.raqam8.TabIndex = 13
        Me.raqam8.Text = "8"
        Me.raqam8.UseVisualStyleBackColor = True
        '
        'raqam9
        '
        Me.raqam9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam9.Location = New System.Drawing.Point(218, 145)
        Me.raqam9.Name = "raqam9"
        Me.raqam9.Size = New System.Drawing.Size(39, 30)
        Me.raqam9.TabIndex = 14
        Me.raqam9.Text = "9"
        Me.raqam9.UseVisualStyleBackColor = True
        '
        'btnkopaytirish
        '
        Me.btnkopaytirish.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnkopaytirish.Location = New System.Drawing.Point(286, 145)
        Me.btnkopaytirish.Name = "btnkopaytirish"
        Me.btnkopaytirish.Size = New System.Drawing.Size(39, 30)
        Me.btnkopaytirish.TabIndex = 15
        Me.btnkopaytirish.Text = "×"
        Me.btnkopaytirish.UseVisualStyleBackColor = True
        '
        'btnbolish
        '
        Me.btnbolish.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbolish.Location = New System.Drawing.Point(286, 197)
        Me.btnbolish.Name = "btnbolish"
        Me.btnbolish.Size = New System.Drawing.Size(39, 30)
        Me.btnbolish.TabIndex = 16
        Me.btnbolish.Text = "/"
        Me.btnbolish.UseVisualStyleBackColor = True
        '
        'btnqoshish
        '
        Me.btnqoshish.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnqoshish.Location = New System.Drawing.Point(286, 248)
        Me.btnqoshish.Name = "btnqoshish"
        Me.btnqoshish.Size = New System.Drawing.Size(39, 30)
        Me.btnqoshish.TabIndex = 17
        Me.btnqoshish.Text = "+"
        Me.btnqoshish.UseVisualStyleBackColor = True
        '
        'btnayirish
        '
        Me.btnayirish.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnayirish.Location = New System.Drawing.Point(286, 300)
        Me.btnayirish.Name = "btnayirish"
        Me.btnayirish.Size = New System.Drawing.Size(39, 30)
        Me.btnayirish.TabIndex = 18
        Me.btnayirish.Text = "-"
        Me.btnayirish.UseVisualStyleBackColor = True
        '
        'raqam4
        '
        Me.raqam4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam4.Location = New System.Drawing.Point(107, 197)
        Me.raqam4.Name = "raqam4"
        Me.raqam4.Size = New System.Drawing.Size(39, 30)
        Me.raqam4.TabIndex = 19
        Me.raqam4.Text = "4"
        Me.raqam4.UseVisualStyleBackColor = True
        '
        'raqam1
        '
        Me.raqam1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam1.Location = New System.Drawing.Point(107, 248)
        Me.raqam1.Name = "raqam1"
        Me.raqam1.Size = New System.Drawing.Size(39, 30)
        Me.raqam1.TabIndex = 20
        Me.raqam1.Text = "1"
        Me.raqam1.UseVisualStyleBackColor = True
        '
        'raqam2
        '
        Me.raqam2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam2.Location = New System.Drawing.Point(163, 248)
        Me.raqam2.Name = "raqam2"
        Me.raqam2.Size = New System.Drawing.Size(39, 30)
        Me.raqam2.TabIndex = 21
        Me.raqam2.Text = "2"
        Me.raqam2.UseVisualStyleBackColor = True
        '
        'raqam3
        '
        Me.raqam3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam3.Location = New System.Drawing.Point(218, 248)
        Me.raqam3.Name = "raqam3"
        Me.raqam3.Size = New System.Drawing.Size(39, 30)
        Me.raqam3.TabIndex = 22
        Me.raqam3.Text = "3"
        Me.raqam3.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.Location = New System.Drawing.Point(163, 300)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(39, 30)
        Me.Button22.TabIndex = 23
        Me.Button22.Text = "0"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.Location = New System.Drawing.Point(218, 299)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(39, 30)
        Me.Button23.TabIndex = 24
        Me.Button23.Text = "."
        Me.Button23.UseVisualStyleBackColor = True
        '
        'tozalash
        '
        Me.tozalash.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tozalash.Location = New System.Drawing.Point(107, 300)
        Me.tozalash.Name = "tozalash"
        Me.tozalash.Size = New System.Drawing.Size(39, 30)
        Me.tozalash.TabIndex = 25
        Me.tozalash.Text = "C"
        Me.tozalash.UseVisualStyleBackColor = True
        '
        'raqam5
        '
        Me.raqam5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam5.Location = New System.Drawing.Point(163, 197)
        Me.raqam5.Name = "raqam5"
        Me.raqam5.Size = New System.Drawing.Size(39, 30)
        Me.raqam5.TabIndex = 26
        Me.raqam5.Text = "5"
        Me.raqam5.UseVisualStyleBackColor = True
        '
        'raqam6
        '
        Me.raqam6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.raqam6.Location = New System.Drawing.Point(218, 197)
        Me.raqam6.Name = "raqam6"
        Me.raqam6.Size = New System.Drawing.Size(39, 30)
        Me.raqam6.TabIndex = 27
        Me.raqam6.Text = "6"
        Me.raqam6.UseVisualStyleBackColor = True
        '
        'lbldisplay
        '
        Me.lbldisplay.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lbldisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbldisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldisplay.Location = New System.Drawing.Point(22, 30)
        Me.lbldisplay.Name = "lbldisplay"
        Me.lbldisplay.Size = New System.Drawing.Size(435, 50)
        Me.lbldisplay.TabIndex = 28
        Me.lbldisplay.Text = "0"
        Me.lbldisplay.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnteng
        '
        Me.btnteng.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnteng.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnteng.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnteng.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnteng.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnteng.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnteng.Location = New System.Drawing.Point(218, 357)
        Me.btnteng.Name = "btnteng"
        Me.btnteng.Size = New System.Drawing.Size(107, 29)
        Me.btnteng.TabIndex = 30
        Me.btnteng.Text = "="
        Me.btnteng.UseMnemonic = False
        Me.btnteng.UseVisualStyleBackColor = False
        Me.btnteng.Visible = False
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(392, 145)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(39, 30)
        Me.Button2.TabIndex = 31
        Me.Button2.Text = "√"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(31, 96)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(63, 30)
        Me.Button8.TabIndex = 35
        Me.Button8.Text = "MRC"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(392, 248)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(39, 30)
        Me.Button3.TabIndex = 41
        Me.Button3.Text = "x√"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Location = New System.Drawing.Point(163, 96)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(39, 30)
        Me.Button14.TabIndex = 42
        Me.Button14.Text = "M-"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Location = New System.Drawing.Point(218, 96)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(39, 30)
        Me.Button15.TabIndex = 43
        Me.Button15.Text = "M*"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.Location = New System.Drawing.Point(286, 96)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(39, 30)
        Me.Button16.TabIndex = 44
        Me.Button16.Text = "M/"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.Location = New System.Drawing.Point(392, 96)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(39, 30)
        Me.Button17.TabIndex = 45
        Me.Button17.Text = "+/-"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(470, 415)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnteng)
        Me.Controls.Add(Me.lbldisplay)
        Me.Controls.Add(Me.raqam6)
        Me.Controls.Add(Me.raqam5)
        Me.Controls.Add(Me.tozalash)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.raqam3)
        Me.Controls.Add(Me.raqam2)
        Me.Controls.Add(Me.raqam1)
        Me.Controls.Add(Me.raqam4)
        Me.Controls.Add(Me.btnayirish)
        Me.Controls.Add(Me.btnqoshish)
        Me.Controls.Add(Me.btnbolish)
        Me.Controls.Add(Me.btnkopaytirish)
        Me.Controls.Add(Me.raqam9)
        Me.Controls.Add(Me.raqam8)
        Me.Controls.Add(Me.raqam7)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button1)
        Me.Cursor = System.Windows.Forms.Cursors.No
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Calculator"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents raqam7 As System.Windows.Forms.Button
    Friend WithEvents raqam8 As System.Windows.Forms.Button
    Friend WithEvents raqam9 As System.Windows.Forms.Button
    Friend WithEvents btnkopaytirish As System.Windows.Forms.Button
    Friend WithEvents btnbolish As System.Windows.Forms.Button
    Friend WithEvents btnqoshish As System.Windows.Forms.Button
    Friend WithEvents btnayirish As System.Windows.Forms.Button
    Friend WithEvents raqam4 As System.Windows.Forms.Button
    Friend WithEvents raqam1 As System.Windows.Forms.Button
    Friend WithEvents raqam2 As System.Windows.Forms.Button
    Friend WithEvents raqam3 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents tozalash As System.Windows.Forms.Button
    Friend WithEvents raqam5 As System.Windows.Forms.Button
    Friend WithEvents raqam6 As System.Windows.Forms.Button
    Friend WithEvents lbldisplay As System.Windows.Forms.Label
    Friend WithEvents btnteng As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button

End Class
